# Nūr pour Android

Application Android de Nūr. Elle ouvre le lecteur public sécurisé dans une interface plein écran, conserve les préférences locales et envoie les liens externes vers le navigateur.

La compilation automatique se lance à chaque mise à jour de la branche `main`. L’APK de test se trouve dans l’onglet **Actions**, dans l’artefact **Nur-Android-APK**.
